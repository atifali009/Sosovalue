## don't use your main account!! & your own risk 

## installation 

```
git clone https://github.com/Mrjihad28/Sosovalue.git
```
```
cd Sosovalue
```
```
python app.py
```

- Now copy `web url` ex. : `http://localhost:8080`
- Open any browser and browse url
- Then back on terminal and open new session.
- Open `proxy.txt` and save your proxy.
```
nano proxy.txt
```

- Then run main script and enjoy
```
python main_bot.py
```
- Input your `web url` & ref code.
- Done ✅

## support 
TG Channel Join Now : t.me/AirdropTube28
